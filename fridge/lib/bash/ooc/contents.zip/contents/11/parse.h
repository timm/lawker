#ifndef	PARSE_H
#define	PARSE_H

/*
 *	error recovery
 */

void error (const char * fmt, ...);

#endif
