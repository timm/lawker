#ifndef	MATHLIB_H
#define	MATHLIB_H

/*
 *	node types
 */

extern const void * Math;

/*
 *	initialization
 */

void initMath (void);

#endif
