#ifndef	VAR_H
#define	VAR_H

/*
 *	node types
 */

const void * Var;
const void * Assign;

/*
 *	initializations
 */

void initConst (void);

#endif
