#ifndef	OBJECT_H
#define	OBJECT_H

extern const void * Object;		/* new(Object); */

int differ (const void * a, const void * b);

#endif
