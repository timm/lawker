Team: Gawking Alum
Member: Aaron Hawley
CSSA Programming Contest
"Votey Checkers"
11:45 PM Monday, February 16, 2004

To users: The name of this Votey Checkers player executable is
``vc5''.  It is implemented in GNU Awk (gawk) version >= 3.1.0 It may
need to be run as `gawk -f vc5.awk -v my_color=1`

To developers: To modify this source code, simply edit any awk source
file with a .awk file extension.  To build the player ``vc-mine''
simply create and edit a file named ``vc-mine-ai.awk'' (see
``vc1-ai.awk'' for starters), then run ``make vc-mine''.


